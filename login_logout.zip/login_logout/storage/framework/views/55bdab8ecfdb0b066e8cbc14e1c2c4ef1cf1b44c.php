
<?php $__env->startSection('admin_content'); ?>
<h1> phong đã ở đây</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\TotNgiep\resources\views/admin/index.blade.php ENDPATH**/ ?>