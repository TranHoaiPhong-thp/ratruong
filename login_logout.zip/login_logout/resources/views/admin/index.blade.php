@extends('layout_admin')
@section('admin_content')
<h1> phong đã ở đây</h1>
@endsection